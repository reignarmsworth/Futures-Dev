﻿Public Class clubForm
    Private Sub ClubForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Add Clubs to the ComboBox
        cmbClubs.Items.Add("Rotary Club")
        cmbClubs.Items.Add("Scouts Troupe")
        cmbClubs.Items.Add("Christian Union")
        cmbClubs.Items.Add("Presidential Award")
    End Sub

    Private Sub cmbClubs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbClubs.SelectedIndexChanged
        If cmbClubs.SelectedItem IsNot Nothing Then
            lblResult.Text = "You selected: " & cmbClubs.SelectedItem.ToString()
        Else
            MessageBox.Show("Please select a club.")
        End If
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Dim loginForm As New LoginForm()
        loginForm.Show()
        Me.Close()
    End Sub
End Class