﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class clubForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        cmbClubs = New ComboBox()
        btnSubmit = New Button()
        lblResult = New Label()
        btnLogout = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(341, 78)
        Label1.Name = "Label1"
        Label1.Size = New Size(95, 20)
        Label1.TabIndex = 0
        Label1.Text = "Select a Club"
        ' 
        ' cmbClubs
        ' 
        cmbClubs.FormattingEnabled = True
        cmbClubs.Location = New Point(341, 112)
        cmbClubs.Name = "cmbClubs"
        cmbClubs.Size = New Size(151, 28)
        cmbClubs.TabIndex = 1
        ' 
        ' btnSubmit
        ' 
        btnSubmit.Location = New Point(341, 156)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(94, 29)
        btnSubmit.TabIndex = 2
        btnSubmit.Text = "Submit"
        btnSubmit.UseVisualStyleBackColor = True
        ' 
        ' lblResult
        ' 
        lblResult.AutoSize = True
        lblResult.Location = New Point(341, 206)
        lblResult.Name = "lblResult"
        lblResult.Size = New Size(153, 20)
        lblResult.TabIndex = 3
        lblResult.Text = "(nothing selected yet)"
        ' 
        ' btnLogout
        ' 
        btnLogout.Location = New Point(12, 409)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(94, 29)
        btnLogout.TabIndex = 4
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = True
        ' 
        ' clubForm
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btnLogout)
        Controls.Add(lblResult)
        Controls.Add(btnSubmit)
        Controls.Add(cmbClubs)
        Controls.Add(Label1)
        Name = "clubForm"
        Text = "Form2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents cmbClubs As ComboBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents lblResult As Label
    Friend WithEvents btnLogout As Button
End Class
