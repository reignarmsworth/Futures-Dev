﻿Public Class LoginForm
    Private Sub Username_Click(sender As Object, e As EventArgs) Handles txtUsername.Click

    End Sub

    Private Sub Username_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged

    End Sub

    Private Sub ClubForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Function ValidateLogin(username As String, password As String) As Boolean
        Dim lines() As String = IO.File.ReadAllLines("users.txt")
        For Each line In lines
            Dim parts() As String = line.Split(","c)
            If parts.Length = 2 Then
                If parts(0).Trim() = username AndAlso parts(1).Trim() = password Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If ValidateLogin(txtUsername.Text, txtPassword.Text) Then
            lblStatus.Text = "Login Successful"
            Dim ClubForm As New clubForm
            ClubForm.Show()
            Me.Hide()
        Else
            lblStatus.Text = "Invalid Username or Password"
        End If
    End Sub


End Class
